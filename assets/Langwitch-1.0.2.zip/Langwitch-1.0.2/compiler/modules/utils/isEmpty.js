let isEmpty = function (str) {
	return (typeof str === "undefined" || str === null || str === "");
}

module.exports.isEmpty = isEmpty;
