# Langwitch
<img src="https://cdn.discordapp.com/attachments/732447814310821959/780667804998172672/20201124_113150.jpg" width="50%">
Hi! This is my first programming language I ever made. I am not pro at it, but I hope you will enjoy it!
## Npm or Pip install
*Download it by going to releases page (download .tar.gz format file)*
